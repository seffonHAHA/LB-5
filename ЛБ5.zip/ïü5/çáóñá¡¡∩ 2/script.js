document.getElementById('getWeatherButton').addEventListener('click', getWeather);

function getWeather() {
  const apiKey = '39a5d336b643f3db3666bac61917836c';
  const cityName = 'Warsaw'; // Місто, для якого отримуємо погоду

  const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=${apiKey}`;

  fetch(apiUrl)
    .then(response => response.json())
    .then(data => {
      // Витягуємо температуру, вологість і швидкість вітру з отриманих даних
      const temperature = data.main.temp;
      const humidity = data.main.humidity;
      const windSpeed = data.wind.speed;

      // Формуємо рядок з даними про погоду
      const weatherInfo = `Температура: ${temperature}°C, Вологість: ${humidity}%, Швидкість вітру: ${windSpeed} м/с`;

      // Виводимо дані на сторінці
      document.getElementById('weatherData').innerText = weatherInfo;
    })
    .catch(error => {
      console.error('Помилка отримання даних про погоду:', error);
      document.getElementById('weatherData').innerText = 'Помилка отримання даних про погоду.';
    });
}
